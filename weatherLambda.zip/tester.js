const axios = require('axios');

async function getWeather(zipCode, apiKey) {
  const baseUrl = 'https://api.openweathermap.org/data/2.5/forecast?';
  const weatherData = (await axios.get(`${baseUrl}zip=${zipCode}&APPID=${apiKey}`));
  return weatherData;
}

getWeather(11747, "5bbda631fbfe391f0fecefcf159156ba").then(data => {
  console.log(data.data.list);
})